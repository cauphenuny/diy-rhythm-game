# 自制谱面音游 / 钢琴模拟器

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

[在线游玩](https://cauphenuny.github.io/deploy/piano-simulator)

功能：

- 使用键盘/鼠标模拟钢琴演奏
- 输入谱子，自动播放
- 自动根据谱子生成音游谱面

![01.jpg](./demo/01.jpg)

![02.jpg](./demo/02.jpg)

![03.jpg](./demo/03.jpg)

![04.jpg](./demo/04.jpg)

![05.jpg](./demo/05.jpg)
